# CLAUDE.md — [Project Name]

> Read this first. It is the entry point for working in this repo.

## What this project is
[One paragraph: what it does, who it's for, what "working" means. Be concrete about the core value — the one thing that must never break.]

## Tech stack
- Language(s): [e.g. TypeScript 5.x, strict mode]
- Runtime: [e.g. Node 20+]
- Framework(s): [e.g. Next.js, Express, Vitest]
- Package manager + lockfile: [e.g. pnpm, committed]

## How to run / test / build
```bash
[install command]
[run command]
[test command]
[build command]
```
Use only the smallest relevant gate after a change — don't run the whole suite for a one-line fix unless asked.

## Architecture (the 60-second version)
- Entry point: [file]
- Layers / domains: [routing → handlers → lib → storage, or your equivalent]
- Where state lives: [db, files, external APIs]
- External dependencies: [APIs, services, and what they're used for]

## Conventions
- Naming: [files, functions, types]
- Error handling: [pattern]
- What NOT to do: [speculative rewrites, new deps without asking, etc.]

## Guardrails (ask before doing)
- [External/public actions, deploys, anything that spends money]
- [Pricing / billing changes]
- [Deleting or overwriting data]
- Never commit secrets, .env, tokens, or credentials.

## Verification
After a change, confirm it actually works before claiming done:
- [the command(s) that prove it]
- For UI: check the actual rendered result, desktop + mobile.

## Definition of done
[A change is done when: tests pass / the gate is green / the behavior is observed working — not when the code is written.]
