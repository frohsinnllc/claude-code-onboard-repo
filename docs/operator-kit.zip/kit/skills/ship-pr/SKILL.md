---
name: ship-pr
description: Use when a change is complete and verified and you need to turn it into a clean pull request — enforces branch hygiene, atomic commits, a real PR description, and a pre-push checklist.
---

# Ship a PR

Goal: get reviewed-ready work onto a branch and into a PR without footguns.

## Pre-flight (do not skip)
- [ ] The change is **verified working** (gate is green / behavior observed). If not, stop and finish that first.
- [ ] You are **not on the default branch**. If you are, create a branch first.
- [ ] No secrets, `.env`, tokens, or build artifacts are staged.

## Steps

1. **Branch.** If on `main`/`master`, create `feat/<short-slug>` or `fix/<short-slug>`.
2. **Stage intentionally.** Review `git diff` and stage only what belongs to this change. Split unrelated work.
3. **Commit atomically.** One logical change per commit. Imperative subject under ~70 chars; body explains *why*, not *what*.
4. **Push** the branch (only when the user has asked you to push).
5. **Open the PR** with this body:
   ```
   ## What
   [1–2 sentences]
   ## Why
   [the motivation / linked issue]
   ## How verified
   [commands run + result, or behavior observed]
   ## Risk / rollback
   [what could break, how to revert]
   ```
6. **Report** the PR URL and the verification evidence — not just "done".

## Guardrails
- Never force-push a shared branch.
- Never merge without the verification section filled in for real.
