# The Operator's Playbook

The kit's files save you setup time. This saves you the expensive mistakes — the confident-but-wrong diffs, the lost afternoons, the "why did it delete that" moments. Read it once, apply it always. Each rule has the principle, a concrete move, and the anti-pattern it kills.

---

## 1. Context before code

The single highest-leverage file in your repo is `CLAUDE.md`. An agent with an accurate project map makes good decisions; one without re-derives them — badly — every session. This is the difference between an agent that feels like a senior engineer on your team and one that feels like a confident intern.

**Do this:** Fill the kit's `CLAUDE.template.md` properly once. The sections that move the needle most: *architecture in 5 lines*, *conventions* (so new code matches old code), and *do-not-touch* (the fragile paths). Update it when the architecture changes, not before.

**Anti-pattern:** A one-line `CLAUDE.md` that says "this is a Node app." That tells the agent nothing it couldn't grep in three seconds, and nothing about your *judgment* — which is the part that's expensive to re-derive.

> Rule of thumb: if you find yourself re-explaining the same thing to the agent in two different sessions, that thing belongs in `CLAUDE.md`.

---

## 2. Scope the smallest real thing

Big vague asks produce big vague diffs. The agent fills ambiguity with assumptions, and you pay for the wrong ones in review. Narrow scope is faster *and* safer — every time.

**Do this:** State the outcome and the boundary in one breath. A reusable shape:

```
Add <specific change>.
Don't touch <the thing you're protecting>.
Done when <observable result> — show me that, not "done".
```

Concrete: *"Add a `--dry-run` flag to the deploy script that prints the steps without running them. Don't touch the real deploy path. Done when `deploy.sh --dry-run` prints all 4 steps and exits 0 without deploying."*

**Anti-pattern:** "Clean up the deploy script." That invites a rewrite you didn't ask for, of code you didn't want touched, verified by nothing.

---

## 3. Verify before you believe

"The code is written" is not "it works." This is the rule that prevents the most wasted cycles, and the one agents skip first. Evidence before assertions, always.

**Do this:** Run the *smallest gate that proves the change* — one test, one build, the actual rendered screen, one curl against the endpoint. Make the agent show you the output, not summarize it. If it says "tests pass," the next line should be the test runner's actual last line.

**Anti-pattern:** Accepting "I've updated the function and it should now work correctly." *Should* is doing a lot of work in that sentence. Untested confidence is how a green-looking session ships a red bug.

> The kit's `ship-pr` skill enforces this: it refuses to write the PR's "How verified" section for you. If you can't fill it, you're not done.

---

## 4. Make changes reversible

Speed comes from being able to undo cheaply, not from never making mistakes. Small commits and clean branches are what let you move fast without fear.

**Do this:** One logical change per commit. Branch off `main` before any non-trivial work (the `ship-pr` skill does this automatically). Before running anything that writes or deletes, look at what it targets first — `git status` before `git add -A`, `ls` before `rm`, read the file before you overwrite it.

**Anti-pattern:** A 40-file "various fixes" commit on `main`. When one of those changes turns out wrong, you can't revert it without reverting the other 39. You traded ten minutes of hygiene for an afternoon of untangling.

---

## 5. Guardrail the irreversible

Most actions are safe to let the agent run freely. A small set are not: spending money, deploying to production, publishing publicly, deleting data, force-pushing. These get an explicit human "go," never a default yes.

**Do this:** Build the work *right up to* the irreversible line so the human's confirmation is one word. Stage the deploy, write the post, prepare the migration — then stop and ask. The kit's `settings.json` keeps these commands off the auto-allow list on purpose.

**Anti-pattern:** A blanket "allow all" permission set because the prompts were annoying. You removed the friction from exactly the three commands where friction was the point.

---

## 6. Don't treat chat as memory

The conversation is not durable state. The next session — yours, a teammate's, or the agent's own after a context reset — starts from *files*, not from a chat it can't see.

**Do this:** When state changes, write it to the file that owns that state: the status doc, the README, the ticket, the migration log. "We decided X because Y" goes in a file, not just in the scrollback.

**Anti-pattern:** Making three important decisions in a long session, then closing it. Next week — or next context window — that reasoning is gone, and you (or the agent) re-litigate it from scratch.

---

## 7. Tune permissions to your real workflow

A good allowlist removes friction on the commands you trust and keeps the prompt on the ones you don't. Flow comes from fewer *unnecessary* interruptions — not from turning off the rails.

**Do this:** Start from the kit's `settings.json`, then trim. Add the read-only and idempotent commands you run constantly (`git status`, `ls`, your test runner, your linter) to the allowlist. Leave anything that writes outside the repo, spends, or deploys on the ask-list. Re-tune every few weeks as your habits change.

**Anti-pattern:** Either extreme — approving every `ls` by hand (death by a thousand prompts), or auto-allowing `rm -rf` and `curl | sh` (death by one).

---

## 8. Know the failure modes

The three ways an agent most reliably wastes your time and trust — and the counter for each:

- **Over-eager rewrites.** It "improves" code you didn't ask it to touch. → Scope the boundary explicitly (Rule 2). Ask for the change requested, nothing more.
- **Silent assumptions.** Blocked on a real decision, it guesses — on something irreversible. → Tell it to surface genuine forks instead of guessing. Cheap choices: pick a sane default and move. Expensive/irreversible ones: stop and ask.
- **Confident wrongness.** A test failed, but the summary says "done." → Demand faithful reporting. If it failed, you want the output and the failure, not optimism. A truthful "this is broken" is worth more than a cheerful "this works."

---

## The whole job, in one line

**Context in → smallest scoped change → verified with evidence → reversible → reported honestly.**

The kit makes the mechanics fast. The playbook keeps them safe. Do both and the agent stops being a gamble and starts being leverage.
