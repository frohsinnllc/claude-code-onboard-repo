# The Operator's Playbook

The kit's files save you setup time. This saves you the expensive mistakes. Short on purpose — read it once, apply it always.

## 1. Context before code
The single biggest lever is the `CLAUDE.md` in your repo. An agent with a good project map makes good decisions; one without re-derives (badly) every session. Fill the template properly once; it pays back every prompt.

## 2. Scope the smallest real thing
Big vague asks produce big vague diffs. State the *outcome* and the *boundary*: "Add X. Don't touch Y. Done when Z is observed." Narrow scope is faster and safer than broad scope, every time.

## 3. Verify before you believe
"The code is written" is not "it works." Run the smallest gate that proves the change — a test, a build, the actual rendered screen. Evidence before assertions. This one habit prevents most wasted cycles.

## 4. Make changes reversible
Small commits, clean branches, no destructive commands without looking first. The cost of a careful diff is minutes; the cost of an unrecoverable mistake is your afternoon and your trust.

## 5. Guardrail the irreversible
Spending money, deploying, publishing publicly, deleting data — these get an explicit confirm, not a default yes. Build the work right up to that line so the human's "go" is one word.

## 6. Don't treat chat as memory
If state changed, write it to the file that owns that state (status doc, README, ticket). The next session — yours or a teammate's — starts from files, not from a conversation it can't see.

## 7. Tune permissions to your real workflow
A good allowlist removes friction on the commands you trust and keeps the prompt on the ones you don't. Re-tune it as your habits change. Flow comes from fewer *unnecessary* interruptions, not from turning off all the rails.

## 8. Know the failure modes
- **Over-eager rewrites** — ask for the change asked for, nothing more.
- **Silent assumptions** — when blocked on a real decision, surface it; don't guess on irreversible things.
- **Confident wrongness** — if a test failed, say so with the output. Faithful reporting beats optimism.

That's the job: context in, small scoped change, verified, reversible, reported honestly. The kit makes the mechanics fast; the playbook keeps them safe.
