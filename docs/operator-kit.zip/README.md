# Claude Code Operator Kit

A premium, install-ready kit for Claude Code power users. Copy it in, get productive in ten minutes, and stop re-deriving your setup on every project.

> One-time purchase · lifetime updates · 7-day refund.

## What's inside

```
kit/
├── settings.example.json      # sane permissions, hooks, defaults
├── CLAUDE.template.md         # project-context template Claude actually uses
├── PLAYBOOK.md                # the operator's workflow, in writing
└── skills/
    ├── onboard-repo/SKILL.md  # map an unfamiliar repo fast
    └── ship-pr/SKILL.md       # branch → commit → PR with guardrails
```

## Install (10 minutes)

1. **Settings.** Copy `kit/settings.example.json` to `~/.claude/settings.json` (global) or `.claude/settings.json` (per-project). Trim the allowlist to what you actually run.
2. **Project context.** Copy `kit/CLAUDE.template.md` to `CLAUDE.md` in your repo root and fill the bracketed sections. This is the single highest-leverage file — it's what makes Claude behave like it knows your codebase.
3. **Skills.** Copy each folder under `kit/skills/` into `.claude/skills/`. Invoke them by name when relevant.
4. **Read the playbook.** `kit/PLAYBOOK.md` is the part most people skip and shouldn't.

## Why it pays for itself

- **Fewer interruptions** — a tuned allowlist means fewer permission prompts, more flow.
- **Repeatable** — same baseline every project; you stop reinventing config.
- **Guardrails** — verification and scoping are baked in, so you make fewer expensive mistakes.

## License

Single-seat commercial license. Use it on your own projects and client work. Don't resell or redistribute the files themselves. Lifetime updates included.

— Built for operators. Questions: claude@frohsinnglobal.com
